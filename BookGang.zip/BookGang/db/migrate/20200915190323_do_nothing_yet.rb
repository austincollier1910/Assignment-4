class DoNothingYet < ActiveRecord::Migration[6.0]

  def up
  end

  def down
  end

end
