require 'test_helper'

class BooksControlControllerTest < ActionDispatch::IntegrationTest
  test "should get Index" do
    get books_control_Index_url
    assert_response :success
  end

  test "should get show" do
    get books_control_show_url
    assert_response :success
  end

  test "should get new" do
    get books_control_new_url
    assert_response :success
  end

  test "should get create" do
    get books_control_create_url
    assert_response :success
  end

  test "should get edit" do
    get books_control_edit_url
    assert_response :success
  end

  test "should get update" do
    get books_control_update_url
    assert_response :success
  end

  test "should get delete" do
    get books_control_delete_url
    assert_response :success
  end

  test "should get destroy" do
    get books_control_destroy_url
    assert_response :success
  end

end
