class MainController < ApplicationController

  layout false

  def index
    render('index')
  end

  def take2
    @array = [1,2,3,4,5]
    @id = params['id']
    @page = params[:page]
    render('take2')
  end


end
